export const LOCAL_STORAGE = {
  TOKEN_KEY: "access_token",
  ROLE: "role",
} as const;
