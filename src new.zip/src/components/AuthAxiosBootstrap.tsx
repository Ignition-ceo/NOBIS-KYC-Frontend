import { useEffect, useRef, useState } from "react";
import { useAuth0 } from "@auth0/auth0-react";
import { attachAuthInterceptor } from "@/lib/api";
import { AxiosReadyContext } from "@/contexts/AxiosReadyContext";

const audience = import.meta.env.VITE_AUTH0_AUDIENCE;

/**
 * Attaches the Axios request interceptor once Auth0 is ready,
 * then signals readiness to the rest of the app via AxiosReadyContext.
 *
 * Wrap your app tree with this component so that any component
 * (e.g. AppStateContext) can call useAxiosReady() before firing
 * authenticated requests.
 */
export default function AuthAxiosBootstrap({
  children,
}: {
  children: React.ReactNode;
}) {
  const { isLoading, getAccessTokenSilently } = useAuth0();
  const attached = useRef(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (isLoading || attached.current) return;
    attached.current = true;

    const detach = attachAuthInterceptor((opts = {}) =>
      getAccessTokenSilently({
        authorizationParams: { audience },
        ...opts,
      })
    );

    setReady(true);

    return detach;
  }, [isLoading, getAccessTokenSilently]);

  return (
    <AxiosReadyContext.Provider value={ready}>
      {children}
    </AxiosReadyContext.Provider>
  );
}
