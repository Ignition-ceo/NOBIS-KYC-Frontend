import React, { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { useAuth0 } from "@auth0/auth0-react";
import { getClientProfile } from "@/services/auth";
import { useAxiosReady } from "@/contexts/AxiosReadyContext";

interface User {
  _id?: string;
  id?: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  companyName?: string;
  [key: string]: unknown;
}

interface AppStateContextType {
  user: User | null;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  loading: boolean;
  refetchUserProfile: () => Promise<void>;
}

const AppStateCtx = createContext<AppStateContextType | undefined>(undefined);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);
  const { isAuthenticated, isLoading: auth0Loading } = useAuth0();
  const axiosReady = useAxiosReady();

  const fetchUser = async () => {
    try {
      setLoading(true);
      // Client dashboard — always fetch client profile
      const data = await getClientProfile();
      if (data?.user) {
        setUser(data.user);
      }
    } catch (error) {
      console.error("Failed to fetch user profile:", error);
    } finally {
      setLoading(false);
    }
  };

  const refetchUserProfile = async () => {
    try {
      const data = await getClientProfile();
      if (data?.user) {
        setUser(data.user);
      }
    } catch (error) {
      console.error("Failed to refetch user profile:", error);
    }
  };

  useEffect(() => {
    // Wait for Auth0 to finish loading AND the Axios auth interceptor
    // to be attached before making any authenticated requests.
    if (!auth0Loading && isAuthenticated && axiosReady) {
      fetchUser();
    }
  }, [auth0Loading, isAuthenticated, axiosReady]);

  return (
    <AppStateCtx.Provider value={{ user, setUser, loading, refetchUserProfile }}>
      {children}
    </AppStateCtx.Provider>
  );
}

export function useAppState() {
  const context = useContext(AppStateCtx);
  if (context === undefined) {
    throw new Error("useAppState must be used within an AppStateProvider");
  }
  return context;
}
