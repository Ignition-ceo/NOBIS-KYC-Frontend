// src/lib/api.ts
// ─────────────────────────────────────────────────────────
// Single Axios instance for the entire app.
// All service files must import { api } from this module.
// ─────────────────────────────────────────────────────────
import axios from "axios";

export const api = axios.create({
  baseURL:
    import.meta.env.VITE_APP_BASE_API_URL ||
    "https://backend-api.getnobis.com/api/v2",
});

// ── Response interceptor (global error handling) ──
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Optional: redirect on 401/403
    if (error?.response?.status === 401) {
      console.warn("[api] Unauthorized — token may be expired");
    }
    return Promise.reject(error);
  }
);

// ── Auth interceptor ────────────────────────────────────
// Call this ONCE from <AuthAxiosBootstrap /> after Auth0 is ready.
// Returns an eject/cleanup function.
export function attachAuthInterceptor(
  getAccessTokenSilently: (opts?: Record<string, unknown>) => Promise<string>
) {
  const reqId = api.interceptors.request.use(async (config) => {
    // Skip if a token was already set manually
    if (config.headers?.Authorization) return config;

    try {
      const token = await getAccessTokenSilently();
      config.headers = config.headers || {};
      config.headers.Authorization = `Bearer ${token}`;
    } catch (err) {
      // Token fetch failed — let the request go through un-authed
      // so the 401 response handler can deal with it.
      console.warn("[api] Could not attach access token:", err);
    }

    return config;
  });

  return () => api.interceptors.request.eject(reqId);
}
